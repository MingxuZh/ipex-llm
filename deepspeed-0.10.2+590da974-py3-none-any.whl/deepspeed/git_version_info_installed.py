version='0.10.2+590da974'
git_hash='590da974'
git_branch='gma/run-opt-branch'
installed_ops={'deepspeed_not_implemented': False, 'deepspeed_ccl_comm': False, 'cpu_adam': False, 'fused_adam': False}
compatible_ops={'deepspeed_not_implemented': False, 'deepspeed_ccl_comm': True, 'cpu_adam': True, 'fused_adam': True}
torch_info={'version': '2.1', 'bf16_support': False, 'cuda_version': '0.0', 'nccl_version': '0.0', 'hip_version': '0.0'}
