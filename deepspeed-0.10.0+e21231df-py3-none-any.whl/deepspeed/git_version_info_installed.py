version='0.10.0+e21231df'
git_hash='e21231df'
git_branch='gma/run-opt-branch'
installed_ops={'deepspeed_not_implemented': False, 'deepspeed_ccl_comm': False}
compatible_ops={'deepspeed_not_implemented': True, 'deepspeed_ccl_comm': True}
torch_info={'version': '2.1', 'bf16_support': False, 'cuda_version': '0.0', 'nccl_version': '0.0', 'hip_version': '0.0'}
